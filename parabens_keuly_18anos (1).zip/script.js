function mostrarMensagem() {
  const msg = document.getElementById('surpresa');
  msg.style.display = 'block';
}
